atoc()		x
ctoa_r()	x
ctoa()		x
extract()	x
compact()	start-up
count()		start-up
split()		x
ltrim()		x
rtrim()		x
slist_free()	x
slist_count()	x

startswith()	lmpell
endswidth()	lmpell
repeat()	lmpell
lower()		HessamLa
upper()		HessamLa
capitalize()	HessamLa

reverse()	Wssingle
trim()		Wssingle
join()		start-up
rfind()		jbpotts
replace()	jbpotts
